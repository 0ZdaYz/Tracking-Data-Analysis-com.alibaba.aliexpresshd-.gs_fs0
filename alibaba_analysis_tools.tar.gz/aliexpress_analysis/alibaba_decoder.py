#!/usr/bin/env python3
"""
Alibaba UTDID .gs_fs0 File Decoder
==================================
Attempts to decrypt Alibaba tracking files using known algorithms.

To use:
1. Get your Android ID: adb shell settings get secure android_id
2. Run: python3 alibaba_decoder.py <android_id>
"""

import sys
import hashlib
import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import struct

# Your device's file contents
FILES_DATA = {
    ".0.jpg": 'zc? WymNS+kP{iV5]uj7#2Cteqe\'@32).-`dR.Td=*V}BDaPLfb*og"8WM5NsYK3*EMsNP>jyz/o1_@X<KeeP',
    ".1.jpg": '\\(K6?3y/\'!E&m8w EK}TuYCk?Y*O[6>(]i\'D{4$h:/GVnqj9x=l1($ZB/|9IhhgC*VGvT#+?UZBzVozOYPE8vw@?HdA{9xC\'umoo zse',
    ".2.jpg": 'd60r9+T0<g;- ">,P$;s>ty;\'4^8)reNppRc?C3O^08v75[ZsQ.<',
    ".3.jpg": 'o/r+grPVaA&@2"g|>r%{_S]TErgu9;|DmUeGBA$M,"uQ?8Vs)hN+hp<$l+d#6gya\\r\'fpMr3rt"dX0nj&lA]X$X-EQ8aBGjt;5c=ik2yQ;8WIbyY\'W-P',
    ".4.jpg": 'tIDL+m8(2?7zVlsDwp9CO 4JD_ PJ%.en^YBJ0qw;{\'1P#!rsV{C2It&F_sY acC',
    ".5.jpg": '+:ADs.keATF:(@W)5MzU>t3@; [?3^zl-tA&SB.z8Nk$s(0JZSi__;DNnjVc!ie.8Y2ExC$D5+pSXZq`k2>neLNP&ai<Ik(T%OD2IDvxWs:,`FJ',
    ".6.jpg": '(KP(;}lO[Uk$?(94,@Hh :>.F6y,nk^BM1:ZelEP(Xx1ix(ayB:=*KcAmB//s$_05@}&$!^{U#X&u^?ZHaIrd4ufdHG+?V>L> "DyN?C$mRGKmPO!?',
    ".7.jpg": 'M#{,OL"sx>W+i?(<G;?5rc8}MB0Sf<XSRr_v|\'#i/sL?)olF>d+ ISJ<tkPvi tn\\MUh,=.c%7b',
    ".8.jpg": 'z&e+\\Bi"-F#+qV&_D.yh$lV2EIB\\w<(Gd%_hW \'xPNWnb|_`SHj9|E"H3DP@4Wq5CovzvTNf6&6wR:N?',
    ".9.jpg": 'Oj>Misbp-4}{Me>h;OZ !Ze``\\?>Di71\\D>"[@9&>0#,e\\lEf%z7@*Cu$|Gd1eoX6t`q*%]AN*wy4U4]omKK::xTj=>7Hq<)\'=JcTnr2g|210hV:g',
    ".10.jpg": 'R[<O`7UlAxi;zqC^,?KU5P#Z5sBNE:@u6}H7MU=$3na8\\3*<sD8l>sX@I;+0\\#|gQSb;Z|Sbe)ND<*-z:%jOeE3kcI;(+v5Pyy:L%WMfb}0',
    ".11.jpg": 'H&<c[frA!mG\'pRx,K.i\'#S}^Vvq97ng4Tm`YlUa0A HD^;sT|A+5',
    ".12.jpg": '-bS{q#5v0yW*]vjwXA\\.Pm5hqE Y[q-k)7oa{Mzb/H=<:?J7cNHELUDGXM,YiXa@E#|d%?Xte!Zc"Hms5b9j`)b5HL|*A&8^M?o>S_Z$`$*l[lnG0:Z/[b}@hL<lYK\'.n)RkQy6:&ovX?c=hVr0S8Ov{m5b`dByx-}6%c@@bHi9LPbT|\\[7+*!lal_sa rWKQ!o[B&_QZ2:CzBtAJ6ab+C|F\'(\\)9^v82N*J,Ffme`Zl;BjA .PyZa-kto J9d-',
}

PACKAGE_NAME = "com.alibaba.aliexpresshd"

# Known salts used by Alibaba SDKs
KNOWN_SALTS = [
    b"",
    b"alibaba",
    b"taobao",
    b"utdid",
    b"alipay",
    b"umeng",
    b"wireless",
    b"security",
    b"1234567890123456",
    b"0123456789abcdef",
]

# Base94 alphabet (printable ASCII 32-125)
BASE94_ALPHABET = ''.join(chr(i) for i in range(32, 126))

def base94_decode(data):
    """Decode Base94 to bytes"""
    result = []
    for char in data:
        if char in BASE94_ALPHABET:
            result.append(BASE94_ALPHABET.index(char))
    return bytes(result)

def base91_decode(data):
    """Decode Base91 to bytes (alternative algorithm)"""
    base91_alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#$%&()*+,./:;<=>?@[]^_`{|}~"'
    
    v = -1
    b = 0
    n = 0
    result = bytearray()
    
    for char in data:
        if char not in base91_alphabet:
            continue
        c = base91_alphabet.index(char)
        if v < 0:
            v = c
        else:
            v += c * 91
            b |= v << n
            n += 13 if (v & 8191) > 88 else 14
            while n > 7:
                result.append(b & 255)
                b >>= 8
                n -= 8
            v = -1
    
    if v >= 0:
        result.append((b | v << n) & 255)
    
    return bytes(result)

def derive_key(android_id, package_name, salt=b""):
    """Derive AES key from device info"""
    # Method 1: MD5(package + android_id + salt)
    data = package_name.encode() + android_id.encode() + salt
    return hashlib.md5(data).digest()

def derive_iv(key):
    """Derive IV from key"""
    return hashlib.md5(key).digest()

def try_aes_decrypt(data, key, iv):
    """Try AES-128-CBC decryption"""
    try:
        cipher = AES.new(key, AES.MODE_CBC, iv)
        decrypted = cipher.decrypt(data)
        # Try to unpad
        try:
            decrypted = unpad(decrypted, AES.block_size)
        except:
            pass
        return decrypted
    except Exception as e:
        return None

def is_valid_decryption(data):
    """Check if decrypted data looks valid"""
    if not data:
        return False
    # Check for high ratio of printable characters
    printable = sum(1 for b in data if 32 <= b <= 126 or b in [9, 10, 13])
    return printable / len(data) > 0.7

def attempt_decrypt(file_data, android_id):
    """Attempt to decrypt file data"""
    results = []
    
    # Try different decoding methods
    decodings = [
        ("Base94", base94_decode(file_data)),
        ("Base91", base91_decode(file_data)),
        ("Raw", file_data.encode('latin-1')),
    ]
    
    for decode_name, decoded in decodings:
        if not decoded or len(decoded) < 16:
            continue
            
        # Pad to AES block size if needed
        if len(decoded) % 16 != 0:
            decoded = decoded + b'\x00' * (16 - len(decoded) % 16)
        
        for salt in KNOWN_SALTS:
            key = derive_key(android_id, PACKAGE_NAME, salt)
            iv = derive_iv(key)
            
            result = try_aes_decrypt(decoded, key, iv)
            if result and is_valid_decryption(result):
                results.append({
                    'decode': decode_name,
                    'salt': salt.decode() if salt else '(none)',
                    'result': result
                })
    
    return results

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        print("\nTo get your Android ID, run on your phone:")
        print("  adb shell settings get secure android_id")
        print("\nOr check Settings → About Phone → Status → Android ID")
        print("\nExample: python3 alibaba_decoder.py a1b2c3d4e5f67890")
        return
    
    android_id = sys.argv[1]
    print(f"=" * 70)
    print(f"Alibaba UTDID Decoder")
    print(f"=" * 70)
    print(f"\nUsing Android ID: {android_id}")
    print(f"Package: {PACKAGE_NAME}")
    
    print(f"\n{'='*70}")
    print("Derived Keys:")
    print(f"{'='*70}")
    
    for salt in KNOWN_SALTS[:5]:
        key = derive_key(android_id, PACKAGE_NAME, salt)
        iv = derive_iv(key)
        print(f"Salt '{salt.decode() if salt else '(none)}':")
        print(f"  Key: {key.hex()}")
        print(f"  IV:  {iv.hex()}")
    
    print(f"\n{'='*70}")
    print("Decryption Attempts:")
    print(f"{'='*70}")
    
    for fname, fdata in sorted(FILES_DATA.items()):
        print(f"\n📄 {fname} ({len(fdata)} bytes)")
        results = attempt_decrypt(fdata, android_id)
        
        if results:
            for r in results:
                print(f"  ✅ Success with {r['decode']}, salt='{r['salt']}'")
                print(f"     Result: {r['result'][:50]}...")
        else:
            print(f"  ❌ No valid decryption found")
            print(f"     (This is expected - key derivation may differ)")

if __name__ == "__main__":
    main()
