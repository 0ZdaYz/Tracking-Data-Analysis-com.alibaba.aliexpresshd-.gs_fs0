import requests
import re
import os

def download_from_apkpure(package_name):
    """Download APK from APKPure"""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    # Get the download page
    url = f"https://apkpure.com/{package_name.replace('.', '-')}/{package_name}/download"
    print(f"Fetching: {url}")
    
    try:
        resp = requests.get(url, headers=headers, timeout=30)
        # Look for direct download link
        matches = re.findall(r'href="(https://[^"]+\.apk[^"]*)"', resp.text)
        if matches:
            apk_url = matches[0]
            print(f"Found APK URL: {apk_url[:80]}...")
            return apk_url
    except Exception as e:
        print(f"Error: {e}")
    return None

def download_from_apkmirror(package_name):
    """Try APKMirror"""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    # Search on APKMirror
    search_url = f"https://www.apkmirror.com/?post_type=app_release&searchtype=apk&s={package_name}"
    print(f"Searching APKMirror...")
    
    try:
        resp = requests.get(search_url, headers=headers, timeout=30)
        return resp.status_code == 200
    except:
        return False

# Try to download AliExpress
package = "com.alibaba.aliexpresshd"
print(f"Attempting to download {package}...")

apk_url = download_from_apkpure(package)
if apk_url:
    print("Use wget to download:", apk_url)
else:
    print("Direct download link not found")
    print("\nAlternative: You can manually download the APK from:")
    print("1. https://apkpure.com/aliexpress/com.alibaba.aliexpresshd")
    print("2. https://www.apkmirror.com/apk/alibaba/")
    print("3. Or extract from your phone using: adb pull /data/app/com.alibaba.aliexpresshd*/base.apk")
