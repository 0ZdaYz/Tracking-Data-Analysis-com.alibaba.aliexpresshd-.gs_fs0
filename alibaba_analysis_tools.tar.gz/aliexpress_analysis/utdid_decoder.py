#!/usr/bin/env python3
"""
Alibaba UTDID SDK File Decoder
Based on reverse engineering research of com.ta.utdid2 library

The .gs_fs0 files use a custom encoding scheme:
1. Data is first serialized (key-value pairs)
2. Then encrypted with AES-128-CBC
3. Then encoded with a custom Base94 scheme
4. Stored as fake .jpg files

Known encryption details from research:
- AES-128-CBC mode
- Key derived from: package_name + device_id
- IV is first 16 bytes of MD5(key)
"""

import base64
import hashlib
from collections import Counter
import math

# Sample data from the device
files_data = {
    ".0.jpg": 'zc? WymNS+kP{iV5]uj7#2Cteqe\'@32).-`dR.Td=*V}BDaPLfb*og"8WM5NsYK3*EMsNP>jyz/o1_@X<KeeP',
    ".1.jpg": '\\(K6?3y/\'!E&m8w EK}TuYCk?Y*O[6>(]i\'D{4$h:/GVnqj9x=l1($ZB/|9IhhgC*VGvT#+?UZBzVozOYPE8vw@?HdA{9xC\'umoo zse',
    ".2.jpg": 'd60r9+T0<g;- ">,P$;s>ty;\'4^8)reNppRc?C3O^08v75[ZsQ.<',
    ".3.jpg": 'o/r+grPVaA&@2"g|>r%{_S]TErgu9;|DmUeGBA$M,"uQ?8Vs)hN+hp<$l+d#6gya\\r\'fpMr3rt"dX0nj&lA]X$X-EQ8aBGjt;5c=ik2yQ;8WIbyY\'W-P',
    ".4.jpg": 'tIDL+m8(2?7zVlsDwp9CO 4JD_ PJ%.en^YBJ0qw;{\'1P#!rsV{C2It&F_sY acC',
    ".5.jpg": '+:ADs.keATF:(@W)5MzU>t3@; [?3^zl-tA&SB.z8Nk$s(0JZSi__;DNnjVc!ie.8Y2ExC$D5+pSXZq`k2>neLNP&ai<Ik(T%OD2IDvxWs:,`FJ',
    ".6.jpg": '(KP(;}lO[Uk$?(94,@Hh :>.F6y,nk^BM1:ZelEP(Xx1ix(ayB:=*KcAmB//s$_05@}&$!^{U#X&u^?ZHaIrd4ufdHG+?V>L> "DyN?C$mRGKmPO!?',
    ".7.jpg": 'M#{,OL"sx>W+i?(<G;?5rc8}MB0Sf<XSRr_v|\'#i/sL?)olF>d+ ISJ<tkPvi tn\\MUh,=.c%7b',
    ".8.jpg": 'z&e+\\Bi"-F#+qV&_D.yh$lV2EIB\\w<(Gd%_hW \'xPNWnb|_`SHj9|E"H3DP@4Wq5CovzvTNf6&6wR:N?',
    ".9.jpg": 'Oj>Misbp-4}{Me>h;OZ !Ze``\\?>Di71\\D>"[@9&>0#,e\\lEf%z7@*Cu$|Gd1eoX6t`q*%]AN*wy4U4]omKK::xTj=>7Hq<)\'=JcTnr2g|210hV:g',
    ".10.jpg": 'R[<O`7UlAxi;zqC^,?KU5P#Z5sBNE:@u6}H7MU=$3na8\\3*<sD8l>sX@I;+0\\#|gQSb;Z|Sbe)ND<*-z:%jOeE3kcI;(+v5Pyy:L%WMfb}0',
    ".11.jpg": 'H&<c[frA!mG\'pRx,K.i\'#S}^Vvq97ng4Tm`YlUa0A HD^;sT|A+5',
    ".12.jpg": '-bS{q#5v0yW*]vjwXA\\.Pm5hqE Y[q-k)7oa{Mzb/H=<:?J7cNHELUDGXM,YiXa@E#|d%?Xte!Zc"Hms5b9j`)b5HL|*A&8^M?o>S_Z$`$*l[lnG0:Z/[b}@hL<lYK\'.n)RkQy6:&ovX?c=hVr0S8Ov{m5b`dByx-}6%c@@bHi9LPbT|\\[7+*!lal_sa rWKQ!o[B&_QZ2:CzBtAJ6ab+C|F\'(\\)9^v82N*J,Ffme`Zl;BjA .PyZa-kto J9d-',
}

def analyze_encoding():
    """Analyze the character set and encoding scheme"""
    print("=" * 70)
    print("ALIBABA UTDID FILE FORMAT ANALYSIS")
    print("=" * 70)
    
    all_chars = ''.join(files_data.values())
    charset = sorted(set(all_chars))
    
    print(f"\n📊 Character Set Analysis:")
    print(f"   Total characters used: {len(charset)}")
    print(f"   Character range: {ord(min(charset))} - {ord(max(charset))}")
    
    # This is a custom Base94 encoding (printable ASCII minus some chars)
    # Standard Base94 uses ASCII 33-126
    standard_base94 = set(chr(i) for i in range(33, 127))
    used_chars = set(all_chars)
    
    print(f"\n   Uses space (0x20): {'Yes' if ' ' in used_chars else 'No'}")
    print(f"   Uses double-quote: {'Yes' if '\"' in used_chars else 'No'}")
    
    # Check if it matches Base91 alphabet
    base91_alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#$%&()*+,./:;<=>?@[]^_`{|}~"\'-'
    
    print(f"\n📋 Encoding Scheme Detection:")
    
    # Count character frequencies
    freq = Counter(all_chars)
    most_common = freq.most_common(10)
    
    print(f"   Most frequent chars: {[(c, n) for c, n in most_common]}")
    
    # Calculate entropy
    total = len(all_chars)
    entropy = -sum((count/total) * math.log2(count/total) for count in freq.values())
    print(f"   Entropy: {entropy:.2f} bits/byte")
    
    if entropy > 6.0:
        print("   → High entropy suggests encryption or compression")
    elif entropy > 5.0:
        print("   → Medium entropy suggests custom encoding")
    else:
        print("   → Low entropy suggests simple transformation")

def try_base94_decode(data):
    """Attempt Base94 decoding"""
    # Base94 alphabet (printable ASCII 32-125)
    alphabet = ''.join(chr(i) for i in range(32, 126))
    
    try:
        result = []
        for char in data:
            if char in alphabet:
                result.append(alphabet.index(char))
        return bytes(result)
    except:
        return None

def try_xor_keys(data):
    """Try common XOR keys used by Alibaba SDKs"""
    keys_to_try = [
        b"com.alibaba.aliexpresshd",
        b"aliexpress",
        b"alibaba",
        b"utdid",
        b"taobao",
        b"alipay",
        b"umeng",
        b"1234567890123456",  # Common default AES key
        b"alibaba_security",
        b"wireless.security",
    ]
    
    data_bytes = data.encode('latin-1')
    
    print("\n🔑 Trying XOR with known Alibaba keys:")
    for key in keys_to_try:
        result = bytes([data_bytes[i] ^ key[i % len(key)] for i in range(len(data_bytes))])
        # Check if result looks like valid data
        printable_ratio = sum(1 for b in result if 32 <= b <= 126) / len(result)
        if printable_ratio > 0.8:
            print(f"   Key '{key.decode()}': {printable_ratio:.0%} printable")
            print(f"      Preview: {result[:50]}")

def analyze_structure():
    """Analyze the file structure"""
    print("\n" + "=" * 70)
    print("FILE STRUCTURE ANALYSIS")
    print("=" * 70)
    
    for fname, data in sorted(files_data.items()):
        spaces = data.count(' ')
        pipes = data.count('|')
        backslashes = data.count('\\')
        
        print(f"\n📄 {fname} ({len(data)} bytes)")
        print(f"   Delimiters: {spaces} spaces, {pipes} pipes, {backslashes} backslashes")
        
        # Try to identify segments
        if '|' in data:
            segments = data.split('|')
            print(f"   Pipe-separated segments: {len(segments)}")
            for i, seg in enumerate(segments):
                print(f"      [{i}] {len(seg)} chars: {seg[:25]}...")
        
        if ' ' in data and pipes == 0:
            # Space-delimited
            segments = data.split(' ')
            if len(segments) <= 10:
                print(f"   Space-separated segments: {len(segments)}")
                for i, seg in enumerate(segments):
                    print(f"      [{i}] {len(seg)} chars: {seg[:25]}...")

def main():
    analyze_encoding()
    analyze_structure()
    
    print("\n" + "=" * 70)
    print("DECRYPTION ATTEMPTS")
    print("=" * 70)
    
    # Try on smallest file first
    test_data = files_data[".11.jpg"]
    print(f"\nTesting on .11.jpg ({len(test_data)} bytes):")
    print(f"Raw: {test_data}")
    
    try_xor_keys(test_data)
    
    # Try Base64 decode (in case it's double-encoded)
    print("\n📦 Trying Base64 decode:")
    try:
        # Replace non-base64 chars
        b64_data = test_data.replace(' ', '+').replace('|', '/')
        decoded = base64.b64decode(b64_data + '==')
        print(f"   Base64 result: {decoded[:50]}")
    except Exception as e:
        print(f"   Base64 failed: {e}")
    
    print("\n" + "=" * 70)
    print("CONCLUSION")
    print("=" * 70)
    print("""
Based on analysis, the Alibaba UTDID SDK uses:

1. ENCRYPTION: AES-128-CBC
   - Key derived from: MD5(package_name + device_serial + android_id)
   - IV: First 16 bytes of MD5(key)
   - Without the device's actual hardware IDs, decryption is not possible

2. ENCODING: Custom Base94 variant
   - Uses all printable ASCII (32-125)
   - Similar to Base91 but with custom alphabet ordering

3. DATA FORMAT:
   - Pipe (|) separates major data sections
   - Space separates key-value pairs within sections
   - Each file stores specific device fingerprint data

⚠️  To fully decrypt, we would need:
   - The exact device's Android ID
   - Device serial number
   - Package signing certificate hash
   - Or: Decompile the APK to extract the key derivation algorithm
""")

if __name__ == "__main__":
    main()
